from xliic_cli.helpers import parser
from xliic_cli.helpers.errors import ScanError
from xliic_cli.helpers.types_helpers import print_warning_message
from xliic_cli.scan.src.owasp_details import get_owasp_issue_detail_by_id, get_owasp_issue_detail_by_name_version


def produce_sarif_from_scan_reports(scan_reports: dict) -> dict:
    try:
        sarif_data: dict = {
            "sarif_artifact_indices": {},
            "sarif_results": [],
            "sarif_files": {},
            "next_artifact_index": 0,
            "next_rule_index": 0,
            "sarif_rule_indices": {},
            "sarif_rules": {},
        }

        sarif_log: dict = {
            "version": "2.1.0",
            "$schema": "http://json.schemastore.org/sarif-2.1.0-rtm.4",
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "42Crunch API Conformance Scan",
                            "informationUri": "https://42crunch.com/",
                            "rules": [],
                        },
                    },
                    "results": sarif_data["sarif_results"],
                    "artifacts": [],
                },
            ],
        }

        for file_name, report in scan_reports.items():
            if report["scanReportVersion"] >= "3.0.0":
                _v2_parse(file_name, report, sarif_data)
            else:
                _v1_parse(file_name, report, sarif_data)

        if sarif_data["sarif_files"].keys():
            sarif_log["runs"][0]["artifacts"] = []
            for path in sarif_data["sarif_files"].keys():
                sarif_log["runs"][0]["artifacts"].append(sarif_data["sarif_files"][path])

        if sarif_data["sarif_rules"].keys():
            for rule_id in sarif_data["sarif_rules"].keys():
                sarif_log["runs"][0]["tool"]["driver"]["rules"].append(sarif_data["sarif_rules"][rule_id])

        return sarif_log
    except Exception as e:
        raise ScanError("Can't create sarif report: ", str(e))


def _v1_parse(file_name, report, sarif_data):
    if report["summary"]["state"] == "finished":
        for path, path_obj in report["paths"].items():
            for method, method_obj in path_obj.items():
                if "issues" in method_obj:
                    for issue in method_obj["issues"]:
                        add_sarif_file(file_name, sarif_data)
                        parsed_file = parser.parse_file(file_name)
                        line, col = parser.get_line_and_col(
                            report["index"]["jsonPointers"][issue["jsonPointer"]], parsed_file
                        )
                        rule_key = report["index"]["injectionKeys"][issue["injectionKey"]]
                        description = report["index"]["injectionDescriptions"][issue["injectionDescription"]]
                        if "injectionDescriptionParams" in issue:
                            for value in issue["injectionDescriptionParams"]:
                                description = description.replace('%s', value, 1)
                        sarif_representation = get_representation(
                            map_level(issue["criticality"]),
                            rule_key,
                            description,
                            file_name,
                            sarif_data["sarif_artifact_indices"][file_name],
                            line,
                            col)
                        add_rule(
                            sarif_data,
                            rule_key,
                            description,
                            get_owasp_issue_detail_by_id(issue["owaspMapping"]),
                            map_severity(issue["criticality"])
                        )
                        sarif_representation["ruleIndex"] = sarif_data["sarif_rule_indices"][rule_key]
                        sarif_data["sarif_results"].append(sarif_representation)
    else:
        print_warning_message(
            f"Skip {file_name} file - scan process not finished, scan status: {report['summary']['state']}"
        )


def _v2_parse(file_name, report, sarif_data):
    if report["summary"]["state"] == "done" or report["summary"]["state"] == "success":
        for path, path_obj in report["methodNotAllowed"].items():
            for method, method_obj in path_obj.items():
                if "conformanceRequestsResults" in method_obj:
                    for issue in method_obj["conformanceRequestsResults"]:
                        test = issue["test"]
                        add_sarif_file(file_name, sarif_data)
                        parsed_file = parser.parse_file(file_name)
                        line, col = parser.get_line_and_col(test["jsonPointer"], parsed_file)
                        sarif_representation = get_representation(
                            map_level(issue["outcome"]["criticality"]),
                            test["key"],
                            test["description"],
                            file_name,
                            sarif_data["sarif_artifact_indices"][file_name],
                            line,
                            col
                        )
                        add_rule(
                            sarif_data,
                            test["key"],
                            test["description"],
                            get_owasp_issue_detail_by_name_version(test["owaspMapping"]),
                            map_severity(issue["outcome"]["criticality"])
                        )
                        sarif_representation["ruleIndex"] = sarif_data["sarif_rule_indices"][test["key"]]
                        sarif_data["sarif_results"].append(sarif_representation)
    else:
        print_warning_message(
            f"Skip {file_name} file - scan process not finished, scan status: {report['summary']['state']}"
        )


def map_level(mapping_number: int) -> str:
    mapping = {0: "none", 1: "note", 2: "warning", 3: "error", 4: "error", 5: "error"}
    # TODO - Change following code to raise an exception. If the inbound criticality 
    # is not one of the numbers above, we must not hide it.
    return mapping.get(mapping_number, "none")


def map_severity(mapping_number: int) -> str:
    mapping = {0: "2", 1: "5", 2: "6", 3: "8", 4: "9.5", 5: "9.5"}
    # TODO - Change following code to raise an exception. If the inbound criticality 
    # is not one of the numbers above, we must not hide it.
    return mapping.get(mapping_number, "2")


def add_sarif_file(file_name, sarif_data):
    if file_name not in sarif_data["sarif_files"]:
        sarif_data["next_artifact_index"] += 1
        sarif_data["sarif_artifact_indices"][file_name] = sarif_data["next_artifact_index"]
        sarif_data["sarif_files"][file_name] = {
            "location": {
                "uri": file_name,
            },
        }

def get_representation(level, rule_id, message, file_name, index, line, col):
    return {
        "level": level,
        "ruleId": rule_id,
        "message": {
            "text": message,
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": file_name,
                        "index": index,
                    },
                    "region": {
                        "startLine": line,
                        "startColumn": col,
                    },
                },
            },
        ],
    }


def add_rule(sarif_data, rule_id, description, owasp_details, severity):
    if rule_id not in sarif_data["sarif_rules"]:
        sarif_data["next_rule_index"] += 1
        sarif_data["sarif_rule_indices"][rule_id] = sarif_data["next_rule_index"]
        help_url = "https://docs.42crunch.com/latest/content/concepts/api_contract_conformance_scan.htm"
        help_text = "To Be Added from KDB"
        sarif_data["sarif_rules"][rule_id] = {
            "id": rule_id,
            "shortDescription": {
                "text": description,
            },
            "helpUri": help_url,
            "help": {
                "text": f"OWASP issue: {owasp_details.short_name}: {owasp_details.long_name}\
                \nDetails: {help_text}",
            },
            "properties": {
                "owasp-issue": owasp_details.long_name,
                "category": "Other",
                "security-severity": severity
            },
        }
