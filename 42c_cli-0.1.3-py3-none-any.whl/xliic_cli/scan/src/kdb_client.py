import yaml
import requests


class ScanKDBClient:
    def __init__(self, scankdb_url: str):
        self.url = scankdb_url
        self.cache = None

    def load_kdb(self):
        response = requests.get(self.url)
        if response.status_code == 200:
            self.cache = yaml.safe_load(response.text)
        else:
            raise Exception(f"Failed to fetch YAML content from URL: {self.url}")

    def get_title (self, target_key: str) -> str:
        # Returns the description attached to a scan test key
        if self.cache is None:
            self.load_kdb()
        
        for item_key, item in self.cache.items():
            if item.get('key') == target_key:
                return item.get('title', None)
        