from xliic_cli.scan.src.scan_client import ScanClient


scan_client = ScanClient("api_1196120e-e529-4a0d-9f24-9a690ed10df7", "https://platform.42crunch.com")
print(scan_client.get_technical_name_by_api_id("a59d38b4-580a-42ee-9b64-1e5421d87567"))
scan_client.create_default_scan_configuration("a59d38b4-580a-42ee-9b64-1e5421d87567")
scan_id = scan_client.read_default_scan_id("a59d38b4-580a-42ee-9b64-1e5421d87567")
print(f"scan id: {scan_id}")
scan_configuration = scan_client.read_scan_configuration(scan_id)
token = scan_configuration["token"]
print(f"token: {scan_id}")
scan_client.run_scan_docker(token)
