import yaml
import requests


class ScanKDBClient:
    def __init__(self, scankdb_url: str):
        self.url = scankdb_url
        self.cache = None

    def load_kdb(self):
        response = requests.get(self.url)
        if response.status_code == 200:
            self.cache = yaml.safe_load(response.text)
        else:
            raise Exception(f"Failed to fetch YAML content from URL: {self.url}")

    def get_title (self, target_key: str) -> str:
        # Returns the description attached to a scan test key
        # Search for the entry based on the key value
        found_entry = None

        for entry_key, entry_data in self.cache.get('InjectionKey', {}).items():
            if entry_data.get('key') == target_key:
                found_entry = entry_data
                break

        if found_entry:
            return found_entry['title']

    def get_description (self, target_key: str) -> str:
        for entry_key, entry_data in self.cache.get('InjectionKey', {}).items():
            if entry_data.get('key') == target_key:
                found_entry = entry_data
                break

        if found_entry:
            return found_entry['shortDescription'] 

    def get_problem_description (self, target_key: str) -> str:
        for entry_key, entry_data in self.cache.get('InjectionKey', {}).items():
            if entry_data.get('key') == target_key:
                found_entry = entry_data
                break

        if found_entry:
            return found_entry['scanDescription'] 
    
    def get_owasp_classification (self, target_key: str) -> int:
        # Returns the description attached to a scan test key
        for entry_key, entry_data in self.cache.get('InjectionKey', {}).items():
            if entry_data.get('key') == target_key:
                found_entry = entry_data
                break

        if found_entry:
            return found_entry['responses']['responseSuccessfulScan']['owaspMapping']
        