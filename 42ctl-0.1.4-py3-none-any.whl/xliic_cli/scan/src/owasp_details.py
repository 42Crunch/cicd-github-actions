from enum import Enum


class OwaspIssueDetail:
    def __init__(self, _id, short_name: str, version: str, long_name: str):
        self.id = _id
        self.short_name = short_name
        self.version = version
        self.long_name = long_name


owaspIssueDetails_2019 = [
    OwaspIssueDetail(
        0,
        'None',
        '2019',
        'No OWASP issues found'
    ),
    OwaspIssueDetail(
        1,
        'API1',
        '2019',
        'Broken Object Level Authorization'
    ),
    OwaspIssueDetail(
        2,
        'API2',
        '2019',
        'Broken User Authentication'
    ),
    OwaspIssueDetail(
        3,
        'API3',
        '2019',
        'Excessive Data Exposure'
    ),
    OwaspIssueDetail(
        4,
        'API4',
        '2019',
        'Lack of Resources & Rate Limiting'
    ),
    OwaspIssueDetail(
        5,
        'API5',
        '2019',
        'Broken Function Level Authorization'
    ),
    OwaspIssueDetail(
        6,
        'API6',
        '2019',
        'Mass Assignment'
    ),
    OwaspIssueDetail(
        7,
        'API7',
        '2019',
        'Security Misconfiguration'
    ),
    OwaspIssueDetail(
        8,
        'API8',
        '2019',
        'Injection'
    ),
    OwaspIssueDetail(
        9,
        'API9',
        '2019',
        'Improper Assets Management'
    ),
    OwaspIssueDetail(
        10,
        'API10',
        '2019',
        'Insufficient Logging & Monitoring'
    )
]

# TO DO : Raise exception if the OWASP data is not found
def get_owasp_issue_detail_by_name_version(nameVersion: str):
    short_name, version = nameVersion.split(":")
    for detail in owaspIssueDetails_2019:
        if detail.short_name == short_name and detail.version == version:
            return detail


# TO DO : Raise exception if the OWASP issue is not found
def get_owasp_issue_detail_by_id(_id: int):
    for detail in owaspIssueDetails_2019:
        if detail.id == _id:
            return detail
