import base64
import gzip
import os
import re
from urllib.parse import urljoin

import requests

from xliic_cli.helpers.errors import TaskError


def upload_sarif_artifact(sarif_file_path):
    # GitHub
    if os.getenv("GITHUB_ACTIONS") == "true":
        print("Uploadinf SARIF file to GitHub Code Scanning")
        _upload_artifact_git(sarif_file_path)
    # Azure
    elif os.getenv("AGENT_ID") is not None:
        print("Will add async task for uploading after others stages")
    # Jenkins
    elif os.getenv("BUILD_ID"):
        print("Upload sarif to Jenkins - i dont know how yet")
    # Gitlab
    elif os.getenv("GITLAB_CI"):
        print("Upload sarif to GitLab - i dont know how yet")
    else:
        raise TaskError(
            "Don't possible understand what CI/CD platforms you use. \
                        Please contact with us and we add support your platform: https://support.42crunch.com/"
        )


def _upload_artifact_git(sarif_file_path):
    github_token = os.getenv("GITHUB_TOKEN")
    owner, repo = os.environ.get("GITHUB_REPOSITORY").split("/")
    ref = os.environ.get("GITHUB_REF")
    commit_sha = os.environ.get("GITHUB_SHA")

    pull_ref_regex = r"refs/pull/(\d+)/merge"
    if re.match(pull_ref_regex, ref):
        ref = re.sub(pull_ref_regex, r"refs/pull/\1/head", ref)
    else:
        ref = ref

    with open(sarif_file_path, "r+") as file:
        sarif_content = file.read()
        compressed_content = gzip.compress(sarif_content.encode())
        zipped_sarif = base64.b64encode(compressed_content).decode()

    base_url = "https://api.github.com"
    endpoint = f"/repos/{owner}/{repo}/code-scanning/sarifs"
    url = urljoin(base_url, endpoint)
    payload = {
        "commit_sha": commit_sha,
        "ref": ref,
        "sarif": zipped_sarif,
        "tool_name": "42Crunch REST API Static Security Testing",
        "checkout_uri": "file://" + os.getcwd(),
    }

    headers = {
        "Authorization": f"Bearer {github_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 202:
        print("SARIF file uploaded successfully")
    else:
        raise TaskError(f"Failed to upload SARIF file, {response.status_code}: {response.text}")
